# eLearnSecurity 2013

name = input("What is your name? ")
surname = input("And you surname? ")
print("Hello", name, surname)
print("Hello " + name + " " + surname)