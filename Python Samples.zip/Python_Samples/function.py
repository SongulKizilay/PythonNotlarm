# eLearnSecurity 2013

def my_sum (x,y):
    """ Return the sum """
    return x + y

#The return value is associated
#to variable x
x = my_sum(5,6)
print("Sum is:",x)

#print the function value
print(my_sum(5,6))

#print the function doc
print("my_sum doc:",my_sum.__doc__)
