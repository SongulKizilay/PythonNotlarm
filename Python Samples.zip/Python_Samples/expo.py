# eLearnSecurity 2013

x = int(input("Enter a number: "))
for i in range(0,x,2):
    print(i, "*2 =", i**2)
