# eLearnSecurity 2013

def by_position(x,y):
    return x-y

res = by_position(10,30)

print(res)
