# eLearnSecurity 2013

print("This program calculates the are of a rectangle")
length = int(input("Length: "))
width = int(input("Width: "))
area = length * width
print("The area is:", area)
