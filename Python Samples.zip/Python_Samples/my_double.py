# eLearnSecurity 2013

""" my_double module """

some_variable = "Just a string"

def my_double(x):
    """ Double the input """
    return x*2
