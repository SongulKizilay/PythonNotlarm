# eLearnSecurity 2013

def by_name(x,y):
    return x-y

res = by_name(y = 30, x = 10)

print(res)
