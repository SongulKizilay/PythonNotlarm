# eLearnSecurity 2013

user_value = int(input("Enter a number: "))
if user_value >= 10:
    print("The value is greater than or equal to 10")
    flag = True
else:
    print("The value is less than 10")
    flag = False
print(flag)
