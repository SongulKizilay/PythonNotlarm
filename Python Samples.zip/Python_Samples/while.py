# eLearnSecurity 2013

user_value = int(input("Insert a number: "))
i = 0
res = 0
while i <= user_value:
    res = res + i
    i += 1
print("Result is: ", res)
