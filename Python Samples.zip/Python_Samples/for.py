# eLearnSecurity 2013

x = 5
y = 10
for x in range(y):
    print("x:",x)
