# eLearnSecurity 2013

n = 0
while n < 10:
    n += 1
    print(n)
